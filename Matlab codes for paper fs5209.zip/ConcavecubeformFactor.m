function scattering_amplitude = ConcavecubeformFactor( paras, qx, qy, qz)
% Calculate the form factor (scattering amplitude) of a 3D concavecube model
%
% Input:
%   - paras: a VECTOR that contains the structural parameters of the model
%   - Qx, Qy, Qz: components of the scattering vector Q along the x,y,z axis.
% Output:
%  - scattering_amplitude: scattering amplitude in a VECTOR form.
%
% Code written by Tianjuan Yang.
%%
a  = paras(1);
b  = paras(2);
 %% Vertex coordinates
v1 = [-a/2,-a/2,a/2];v2 = [a/2,-a/2,a/2];v3 = [a/2,a/2,a/2];v4 = [-a/2,a/2,a/2];v5 = [0, 0, a/2-b];
v6 = [-a/2,-a/2,-a/2];v7 = [a/2,-a/2,-a/2];v8 = [a/2,a/2,-a/2];v9 = [-a/2,a/2,-a/2];v10 = [0, 0, -a/2+b]; 
%% using projection method
v11 = [0,  a/2-b,0];v12 = [-a/2+b,0,0];v13 = [0,-a/2+b,0];v14 = [a/2-b,0,0];
V1 = v5;V2 = v1;V3 = v2;
f1 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v5;V2 = v2;V3 = v3;
f2 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v5;V2 = v3;V3 = v4;
f3 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v5;V2 = v4;V3 = v1;
f4 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v1;V2 = v6;V3 = v13;
f5 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v1;V2 = v13;V3 = v2;
f6 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v2;V2 = v13;V3 = v7;
f7 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v7;V2 = v13;V3 = v6;
f8 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v2;V2 = v14;V3 = v3;
f9 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v3;V2 = v14;V3 = v8;
f10 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v8;V2 = v14;V3 = v7;
f11 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v7;V2 = v14;V3 = v2;
f12 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v3;V2 = v11;V3 = v4;
f13 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v4;V2 = v11;V3 = v9;
f14 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v9;V2 = v11;V3 = v8;
f15 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v8;V2 = v11;V3 = v3;
f16 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v4;V2 = v12;V3 = v1;
f17 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v1;V2 = v12;V3 = v6;
f18 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v6;V2 = v12;V3 = v9;
f19 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v9;V2 = v12;V3 = v4;
f20 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v6;V2 = v10;V3 = v7;
f21 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v7;V2 = v10;V3 = v8;
f22 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v8;V2 = v10;V3 = v9;
f23 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v9;V2 = v10;V3 = v6;
f24 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);

scattering_amplitude = f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12 +...
    f13 + f14 + f15 + f16 + f17 + f18 + f19 + f20 + f21 + f22 + f23 + f24;
end
