function scattering_amplitude = Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz)
% Calculate the form factor (scattering amplitude) of orthogonal tetrahedra.
% Code written by Tianjuan Yang.

global DENSITY

T = [V1(1) V2(1) V3(1);V1(2) V2(2) V3(2) ;V1(3) V2(3) V3(3)];
Q1 = qx*V1(1) + qy*V1(2) + qz*V1(3);
Q2 = qx*V2(1) + qy*V2(2) + qz*V2(3);
Q3 = qx*V3(1) + qy*V3(2) + qz*V3(3);
det_T = det(T);

scattering_amplitude = DENSITY*abs(det_T)*(-1i*exp(-1i*Q3)./(Q3.*(Q3 - Q2).*(Q3 - Q1)) - 1i*exp(-1i.*Q2)./(Q2.*(Q2 - Q1).*(Q2 - Q3)) -...
    1i*exp(-1i.*Q1)./(Q1.*(Q1 - Q2).*(Q1 - Q3)) + 1i./(Q1.*Q2.*Q3));
%% calculation at singularities
[row1] = find(Q1== 0 & Q2~=Q3 & Q2~=0 & Q3~=0);
scattering_amplitude(row1) =  DENSITY*abs(det_T)*(-1i*exp(-1i*Q2(row1))./(Q2(row1).^2.*(Q2(row1) - Q3(row1))) -1i*exp(-1i*Q3(row1))./(Q3(row1).^2.*(Q3(row1) - Q2(row1)))-1i*(Q2(row1) + Q3(row1)-1i*Q2(row1).*Q3(row1))./(Q2(row1).^2.*Q3(row1).^2));
[row2] = find(Q2== 0 & Q1~=Q3 & Q1~=0 & Q3~=0);
scattering_amplitude(row2) =  DENSITY*abs(det_T)*(-1i*exp(-1i*Q1(row2))./(Q1(row2).^2.*(Q1(row2) - Q3(row2))) -1i*exp(-1i*Q3(row2))./(Q3(row2).^2.*(Q3(row2) - Q1(row2)))-1i*(Q1(row2) + Q3(row2)-1i*Q1(row2).*Q3(row2))./(Q1(row2).^2.*Q3(row2).^2));
[row3] = find(Q3== 0 & Q1~=Q2 & Q1~=0 & Q2~=0);
scattering_amplitude(row3) =  DENSITY*abs(det_T)*(-1i*exp(-1i*Q1(row3))./(Q1(row3).^2.*(Q1(row3) - Q2(row3))) -1i*exp(-1i*Q2(row3))./(Q2(row3).^2.*(Q2(row3) - Q1(row3)))-1i*(Q1(row3) + Q2(row3)-1i*Q1(row3).*Q2(row3))./(Q1(row3).^2.*Q2(row3).^2));
[row4] = find(Q1== Q3 & Q1~=0 & Q1~=Q2 & Q2~=0);
scattering_amplitude(row4) =  DENSITY*abs(det_T)*(-1i*exp(-1i*Q2(row4))./(Q2(row4).*(Q2(row4) - Q1(row4)).^2) + exp(-1i.*Q1(row4)).*(-1i*Q2(row4) + Q1(row4).*(2i + Q2(row4) - Q1(row4)))./(Q2(row4) - Q1(row4)).^2./Q1(row4).^2 + 1i./(Q1(row4).^2.*Q2(row4)));
[row5] = find(Q1== Q2 & Q1~=0 & Q1~=Q3 & Q3~=0);
scattering_amplitude(row5) =  DENSITY*abs(det_T)*(-1i*exp(-1i*Q3(row5))./(Q3(row5).*(Q3(row5) - Q1(row5)).^2) + exp(-1i.*Q1(row5)).*(-1i*Q3(row5) + Q1(row5).*(2i + Q3(row5) - Q1(row5)))./(Q3(row5) - Q1(row5)).^2./Q1(row5).^2 + 1i./(Q1(row5).^2.*Q3(row5)));
[row6] = find(Q2== Q3 & Q2~=0 & Q1~=Q2 & Q1~=0);
scattering_amplitude(row6) =  DENSITY*abs(det_T)*(-1i*exp(-1i*Q1(row6))./(Q1(row6).*(Q1(row6) - Q2(row6)).^2) + exp(-1i.*Q2(row6)).*(-1i*Q1(row6) + Q2(row6).*(2i + Q1(row6) - Q2(row6)))./(Q1(row6) - Q2(row6)).^2./Q2(row6).^2 + 1i./(Q2(row6).^2.*Q1(row6)));
[row7] = find(Q1== Q2 & Q2==Q3 & Q1~=0);
scattering_amplitude(row7) =  DENSITY*abs(det_T)*(exp(-1i*Q1(row7)).*(-2i + 2*Q1(row7) + 1i* Q1(row7).^2)./(2*Q1(row7).^3 )+ 1i./Q1(row7).^3);
[row8] = find(Q1== 0 & Q2==0 & Q3==0);
scattering_amplitude(row8) =  DENSITY*abs(det_T)/6;

end