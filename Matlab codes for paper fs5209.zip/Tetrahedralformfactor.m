function FT = Tetrahedralformfactor(paras, qx, qy, qz)
% Calculate the form factor (scattering amplitude) of a 3D tetrahedra model
%
% Input:
%   - paras: a VECTOR that contains the structural parameters of the tetrahedra model
%   - Qx, Qy, Qz: components of the scattering vector Q along the x,y,z axis.
% Output:
%  - scattering_amplitude: scattering amplitude in a VECTOR form.
%
% Code written by Tianjuan Yang, 2021-10-25.
%% Tetrahedral_formfactor (The origin of the coordination system at the tip of the Tetrahedron )
% using proposed method
a = paras(1);
V1 = [-a/2 -sqrt(3)*a/6 -a*sqrt(6)/3];
V2 = [a/2 -a*sqrt(3)/6 -a*sqrt(6)/3];
V3 = [0 sqrt(3)*a/3 -a*sqrt(6)/3];

FT = Orthodonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);

end