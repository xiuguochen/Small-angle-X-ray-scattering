function scattering_amplitude =   CubicformFactor(paras,qx,qy,qz)
% Calculate the form factor (scattering amplitude) of the cube.
% Input:
%   - paras: a VECTOR that contains the structural parameters of the
%              cubic feature, including width, height, etc. 
%  
%   - qx,qy,qz : scattering vector
% Output:
%   - scattering_amplitude: scattering amplitude in a VECTOR form.
%
% Code written by Tianjuan Yang.
%%
global DENSITY
a  = paras(1);
b  = paras(2);
h  = paras(3);
%% Vertex coordinates
V1 = [-b/2 -a/2 h/2];V2 = [b/2 -a/2 h/2];V3 = [b/2 a/2 h/2];V4 = [-b/2 a/2 h/2];V5 = [-b/2 -a/2 -h/2];V6 = [b/2 -a/2 -h/2];V7 = [b/2 a/2 -h/2];V8 = [-b/2 a/2 -h/2];
%% using projection method
f1 = Orthogonal_tetrahedra_formfactor(V1,V5,V2, qx, qy, qz);
f2 = Orthogonal_tetrahedra_formfactor(V2,V5,V6, qx, qy, qz);
f3 = Orthogonal_tetrahedra_formfactor(V2,V6,V7, qx, qy, qz);
f4 = Orthogonal_tetrahedra_formfactor(V2,V7,V3, qx, qy, qz);
f5 = Orthogonal_tetrahedra_formfactor(V3,V7,V8, qx, qy, qz);
f6 = Orthogonal_tetrahedra_formfactor(V3,V8,V4, qx, qy, qz);
f7 = Orthogonal_tetrahedra_formfactor(V4,V8,V1, qx, qy, qz);
f8 = Orthogonal_tetrahedra_formfactor(V1,V8,V5, qx, qy, qz);
f9 = Orthogonal_tetrahedra_formfactor(V7,V6,V5, qx, qy, qz);
f10 = Orthogonal_tetrahedra_formfactor(V7,V5,V8, qx, qy, qz);
f11 = Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
f12 = Orthogonal_tetrahedra_formfactor(V1,V3,V4, qx, qy, qz);
scattering_amplitude =f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12;

end