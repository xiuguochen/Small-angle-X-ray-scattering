This code simulates the intensity distributions (RSM and slices) of various polyhedron particles.  These particles include:  cube, 3D trapezoid cross section model,
octahedron, dodecahedron, icosahedron and concave cube model.


The specific implementation steps of the program are as follows:
1、Open the main_polyhedron program, set different rotation conditions and compute the q vector distribution.
2、Select a polyhedron model and set the model parameters. For example,  select the 'cube parameters'  code section for the cube particle.
2、Select RSM mode or scattering curve (slices) mode based on the requirement, plot the intensity distribution and save the data.



 Powered by Nanoscale and Optical Metrology (NOM) Group, Huazhong University of Science and Technology, China.
 All Rights Reserved.
 Program revised by Tianjuan Yang. ////////