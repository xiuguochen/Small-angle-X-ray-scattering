function scattering_amplitude = Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz)
% Calculate the form factor (scattering amplitude) of orthogonal tetrahedra.
% Code written by Tianjuan Yang.

global DENSITY

T = [V1(1) V2(1) V3(1);V1(2) V2(2) V3(2) ;V1(3) V2(3) V3(3)];
Q1 = qx*V1(1) + qy*V1(2) + qz*V1(3);
Q2 = qx*V2(1) + qy*V2(2) + qz*V2(3);
Q3 = qx*V3(1) + qy*V3(2) + qz*V3(3);
det_T = det(T);


scattering_amplitude = DENSITY*det_T.*(1i*exp(1i.*Q3)./(Q3.*(Q3 - Q2).*(Q3 - Q1)) + 1i*exp(1i.*Q2)./(Q2.*(Q2 - Q1).*(Q2 - Q3)) +...
    1i*exp(1i.*Q1)./(Q1.*(Q1- Q2).*(Q1 - Q3)) - 1i./(Q1.*Q2.*Q3));
%% calculation at singularities
[row2] = find(abs(Q1)<= 1e-9 & abs(Q2)>= 1e-9 & abs(Q3)>= 1e-9 & abs(Q2-Q3)>= 1e-9);
scattering_amplitude(row2) =  DENSITY*det_T.*(1i*exp(1i*Q2(row2))./(Q2(row2).^2.*(Q2(row2) - Q3(row2))) + 1i*exp(1i*Q3(row2))./(Q3(row2).^2.*(Q3(row2) - Q2(row2))) + 1i*(Q2(row2) + Q3(row2)+1i*Q2(row2).*Q3(row2))./(Q2(row2).^2.*Q3(row2).^2));
[row3] = find(abs(Q2)<= 1e-9 & abs(Q1)>= 1e-9 & abs(Q3)>= 1e-9 & abs(Q1-Q3)>= 1e-9);
scattering_amplitude(row3) =  DENSITY*det_T.*(1i*exp(1i*Q1(row3))./(Q1(row3).^2.*(Q1(row3) - Q3(row3))) + 1i*exp(1i*Q3(row3))./(Q3(row3).^2.*(Q3(row3) - Q1(row3))) + 1i*(Q1(row3) + Q3(row3)+1i*Q1(row3).*Q3(row3))./(Q1(row3).^2.*Q3(row3).^2));
[row4] = find(abs(Q3)<= 1e-9 & abs(Q1)>= 1e-9 & abs(Q2)>= 1e-9 & abs(Q1-Q2)>= 1e-9);
scattering_amplitude(row4) =  DENSITY*det_T.*(1i*exp(1i*Q1(row4))./(Q1(row4).^2.*(Q1(row4) - Q2(row4))) + 1i*exp(1i*Q2(row4))./(Q2(row4).^2.*(Q2(row4) - Q1(row4))) + 1i*(Q1(row4) + Q2(row4)+1i*Q1(row4).*Q2(row4))./(Q1(row4).^2.*Q2(row4).^2));
[row5] = find(abs(Q1-Q3)< 1e-9 & abs(Q1)>= 1e-9 & abs(Q1-Q2)>= 1e-9 & abs(Q3)>= 1e-9);
scattering_amplitude(row5) =  DENSITY*det_T.*(1i*exp(1i*Q2(row5))./(Q2(row5).*(Q2(row5) - Q1(row5)).^2) + exp(1i.*Q1(row5)).*(1i*Q2(row5) - 2i*Q1(row5)- Q1(row5).^2 + Q1(row5).*Q2(row5))./(Q2(row5) - Q1(row5)).^2./Q1(row5).^2 - 1i./(Q1(row5).^2.*Q2(row5)));
[row6] = find(abs(Q1-Q2)< 1e-9 & abs(Q1)>= 1e-9 & abs(Q2-Q3)>= 1e-9 & abs(Q2)>= 1e-9);
scattering_amplitude(row6) =  DENSITY*det_T.*(1i*exp(1i*Q3(row6))./(Q3(row6).*(Q3(row6) - Q1(row6)).^2) + exp(1i.*Q1(row6)).*(1i*Q3(row6) - 2i*Q1(row6)- Q1(row6).^2 + Q1(row6).*Q3(row6))./(Q3(row6) - Q1(row6)).^2./Q1(row6).^2 - 1i./(Q1(row6).^2.*Q3(row6)));
[row7] = find(abs(Q2-Q3)< 1e-9 & abs(Q2)>= 1e-9 & abs(Q1-Q3)>= 1e-9 & abs(Q3)>= 1e-9);
scattering_amplitude(row7) = DENSITY*det_T.*(1i*exp(1i*Q1(row7))./(Q1(row7).*(Q1(row7) - Q2(row7)).^2) + exp(1i.*Q2(row7)).*(1i*Q1(row7) - 2i*Q2(row7)- Q2(row7).^2 + Q2(row7).*Q1(row7))./(Q1(row7) - Q2(row7)).^2./Q2(row7).^2 - 1i./(Q2(row7).^2.*Q1(row7)));
[row8] = find(abs(Q1-Q2)<= 1e-5 & abs(Q1-Q3)<= 1e-5 & abs(Q2-Q3)<= 1e-5 & abs(Q1)>= 1e-9& abs(Q2)>= 1e-9& abs(Q3)>= 1e-9);
scattering_amplitude(row8) =  DENSITY*det_T.*(exp(1i*Q1(row8)).*(2i + 2*Q1(row8) - 1i* Q1(row8).^2)./(2*Q1(row8).^3 )- 1i./Q1(row8).^3);
[row9] = find(Q1.^2 +Q2.^2 + Q3.^2 < 1e-3 );
scattering_amplitude(row9) =  DENSITY*det_T/6 +  i*det_T*(Q1(row9) + Q2(row9) + Q3(row9));

end