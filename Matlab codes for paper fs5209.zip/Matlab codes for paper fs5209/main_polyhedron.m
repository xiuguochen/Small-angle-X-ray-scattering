%   MATLAB program for the scattering of polyhedron particles.

%   Powered by Nanoscale and Optical Metrology (NOM) Group, Huazhong University of Science and Technology, China.
%   All Rights Reserved.
%
%   Program revised by Tianjuan Yang. ////////
format long
clear; clc;
addpath(genpath(pwd))
%% simulation condition /////////////////////
global DENSITY
tic
SDD = 8.5e9;                              % in nanometer, sample to detector distance
Pixel = 172e3;                            % in nanometer, detector's resolution per pixel
Numpixelx = 1475;                         % detector with 1475 pixels along x direction
Numpixely = 1475;                         % detector with 1475 pixels along y direction
wavelength = 0.0729;                      % in nanometer, wave length corresponding to 17 KeV                    
DENSITY = 2.8783;                         % electron density
Thetaf = atand(Pixel*[-Numpixelx/2:Numpixelx/2]/SDD);                                                  % in degree, diffraction angles along x direction
Alphaf = atand(Pixel*[-Numpixely/2:Numpixely/2]/SDD);                                                  % in degree, diffraction angles along y direction
[thetaf, alphaf] = meshgrid(Thetaf,Alphaf);
%% rotation condition /////////////////////
Omega  = 0;                               % in degree, rotation angle along the y-axis
Phi = 0;                                  % in degree, rotation angle along the x-axis
Gamma = 0;                               % in degree, rotation angle along the z-axis
Rz = [cosd(Gamma) sind(Gamma) 0; -sind(Gamma) cosd(Gamma) 0; 0 0 1] ;        
Ry = [cosd(Omega) 0 -sind(Omega);  0 1 0; sind(Omega) 0 cosd(Omega)];        
Rx = [1 0 0; 0 cosd(Phi) sind(Phi); 0 -sind(Phi) cosd(Phi)];                 
R = Rz*Ry*Rx;                             % rotation matrix 
%% computing the distribution of q vector at different orientations
qx =  2*pi/wavelength*cosd(alphaf).*sind(thetaf);
qy =  2*pi/wavelength*sind(alphaf);
qz =  2*pi/wavelength*(cosd(alphaf).*cosd(thetaf) - 1);

Qx = R(1,1)*qx + R(1,2)*qy + R(1,3)*qz;
Qy = R(2,1)*qx + R(2,2)*qy + R(2,3)*qz;
Qz = R(3,1)*qx + R(3,2)*qy + R(3,3)*qz;

%% cube parameters
a  = 30;                                % in nanometer, length along y direction
b  = 20;                                % in nanometer, length along x direction
h  = 40;                                % in nanometer, length along z direction
formfactor_paras = [a,b,h];      
formfactor = CubicformFactor(formfactor_paras, Qx, Qy, Qz);

% %%obtained from the direct integrated method
RSMap1 = abs( a*b*h*DENSITY*sinc(Qx*b/2/pi).*sinc(Qy*a/2/pi).*sinc(Qz*h/2/pi)).^2; 
%% tarpzoidal cross section parameters
% a  = 30;                                % in nanometer, length along y direction
% b  = 20;                                % in nanometer, length along x direction
% h  = 40;                                % in nanometer, length along z direction
% SWA1 = 20;                              % in degree, side wall angle
% SWA2 = 20;                              % in degree, side wall angle
% formfactor_paras = [a,b,h,SWA1,SWA2];    
% formfactor = TrapezoidalFormFactor3D(formfactor_paras, Qx, Qy, Qz);

% %%obtained from the direct integrated method
% slope1 = tand(SWA1);
% slope2 = tand(SWA2);
% RSMap1 = abs(DENSITY*(exp(-1j*Qx*a/2).*(exp(-1j*b*(Qy - Qx*slope2)) - 1)./(Qx.*(slope2*Qx - Qy)) + ...
%     exp(1j*Qx*a/2).*(exp(-1j*b*(Qy + Qx*slope1)) - 1)./(Qx.*(slope1*Qx + Qy))).*(2*sin(Qz*h/2))./Qz.*(exp(1j*(Qy*b/2)))).^2; 
%% Octahedron parameters
% a = 20;                                   % in nanometer, side length
% formfactor_paras = [a];                  
% formfactor = OctahedralformFactor(formfactor_paras, Qx, Qy, Qz);
%% Dodecahedron parameters
% a  = 20*(sqrt(5)-1);                      % in nanometer, side length
% formfactor_paras = [a];                  
% formfactor = DodecahedralformFactor(formfactor_paras, Qx, Qy, Qz);
%% icosahedron parameters
% a  = 20;                                  % in nanometer, side length
% formfactor_paras = [a];                
% formfactor = IcosahedralformFactor(formfactor_paras, Qx, Qy, Qz);
%% concave cube   
% a = 30;                                   % in nanometer, side length
% b = 3;                                    % in nanometer, depth of concavity
% formfactor_paras = [a,b];               
% formfactor = ConcavecubeformFactor(formfactor_paras, Qx, Qy, Qz);                        
%% plot RSMap
RSMap = abs(formfactor).^2; 

figure
contour(qx,qy,log(RSMap),200)
xlabel('\itq\rm_{\itx\rm} [nm^-^1]', 'FontName', 'Times New Roman', 'FontSize',11);
ylabel('\itq\rm_{\ity\rm} [nm^-^1]', 'FontName', 'Times New Roman', 'FontSize',11);
colorbar
u2 = colorbar;
colormap(jet);
set(get(u2,'title'),'string','log(\it\bfI)','FontSize',11,'Fontname', 'Times New Roman');
title('Simulated RSM in the symmetric direction','FontName', 'Times New Roman', 'FontSize',11)
set(gca,'FontSize',11,'Fontname', 'Times New Roman');
set(gcf,'unit','centimeters','position',[10 5 9 7]);
%% plot slices

figure
plot(Qx(50,:),log(RSMap(50,:)),'-','Color',[0.97,0.69,0.03],'Linewidth', 2)
hold on
plot(Qx(50,:),log(RSMap1(50,:)),'--','Color',[0.45,0.03,0.11],'Linewidth', 2)
xlabel('\itq\rm_{\itx\rm} [nm^-^1]', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('log(\it\bfI\rm) [a.u.]', 'FontName', 'Times New Roman', 'FontSize', 11)
legend('Direct integration method','Proposed method','FontName', 'Times New Roman', 'Fontsize', 11)
title('\itq\rm_{\itx\rm}  slices ','FontName', 'Times New Roman', 'Fontsize', 11)
set(gca,'FontSize',11,'Fontname', 'Times New Roman');
set(gcf,'unit','centimeters','position',[10 5 9 7]);

figure
plot(Qx(50,:),log(abs(RSMap(50,:)-RSMap1(50,:))),'-','Color',[0.04,0.31,0.42],'Linewidth', 0.5)
xlabel('\itq\rm [nm^-^1]', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('log(\it\bf\Delta\it\bfI\rm) [a.u.]', 'FontName', 'Times New Roman', 'FontSize', 11)
title(' Absolute error','FontName', 'Times New Roman', 'FontSize',11)
set(gca,'FontSize',11,'Fontname', 'Times New Roman');
set(gcf,'unit','centimeters','position',[10 5 9 7]);
grid on
toc