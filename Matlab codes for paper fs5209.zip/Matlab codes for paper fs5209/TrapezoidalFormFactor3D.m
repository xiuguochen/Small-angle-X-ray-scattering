function scattering_amplitude = TrapezoidalFormFactor3D(paras, qx, qy, qz)
% Calculate the form factor (scattering amplitude) of a 3D trapezoidal model
%
% Input:
%   - paras: a VECTOR that contains the structural parameters of the
%   trapezoidal cross-section, including widths, height, SWAs.
%   - qx, qy, qz: components of the scattering vector Q along the x,y,z axis.
% Output:
%  - scattering_amplitude: scattering amplitude in a VECTOR form.
%
% Code written by Tianjuan Yang.
%%
global DENSITY
a  = paras(1);
b  = paras(2);
h = paras(3);
slope1 = tand(paras(4));
slope2 = tand(paras(5));
%% Vertex coordinates
V1 = [-a/2,-b/2 ,h/2];V2 = [a/2 -b/2 ,h/2];V3 =[a/2 - b*slope2,b/2 ,h/2];V4 =[-a/2 + b*slope1,b/2 ,h/2];
V5 = [-a/2,-b/2 ,-h/2];V6 = [a/2 -b/2 ,-h/2];V7 =[a/2 - b*slope2,b/2 ,-h/2];V8 =[-a/2 + b*slope1,b/2 ,-h/2];
%% using projection method
f1 = Orthogonal_tetrahedra_formfactor(V1,V5,V2, qx, qy, qz);
f2 = Orthogonal_tetrahedra_formfactor(V2,V5,V6, qx, qy, qz);
f3 = Orthogonal_tetrahedra_formfactor(V2,V6,V7, qx, qy, qz);
f4 = Orthogonal_tetrahedra_formfactor(V2,V7,V3, qx, qy, qz);
f5 = Orthogonal_tetrahedra_formfactor(V3,V7,V8, qx, qy, qz);
f6 = Orthogonal_tetrahedra_formfactor(V3,V8,V4, qx, qy, qz);
f7 = Orthogonal_tetrahedra_formfactor(V4,V8,V1, qx, qy, qz);
f8 = Orthogonal_tetrahedra_formfactor(V1,V8,V5, qx, qy, qz);
f9 = Orthogonal_tetrahedra_formfactor(V7,V6,V5, qx, qy, qz);
f10 = Orthogonal_tetrahedra_formfactor(V7,V5,V8, qx, qy, qz);
f11 = Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
f12 = Orthogonal_tetrahedra_formfactor(V1,V3,V4, qx, qy, qz);
scattering_amplitude = f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12; 
%% using integrated method
% scattering_amplitude = DENSITY*(exp(-1j*qx*a/2).*(exp(-1j*b*(qy - qx*slope2)) - 1)./(qx.*(slope2*qx - qy)) + ...
%     exp(1j*qx*a/2).*(exp(-1j*b*(qy + qx*slope1)) - 1)./(qx.*(slope1*qx + qy))).*(2*sin(qz*h/2))./qz.*(exp(1j*(qy*b/2)));
% end