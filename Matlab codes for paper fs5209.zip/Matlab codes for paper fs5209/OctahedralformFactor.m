function scattering_amplitude = OctahedralformFactor(paras, qx, qy, qz)
% Calculate the form factor (scattering amplitude) of a 3D octahedral model
%
% Input:
%   - paras: a VECTOR that contains the structural parameters of the model
%   - Qx, Qy, Qz: components of the scattering vector Q along the x,y,z axis.
% Output:
%  - scattering_amplitude: scattering amplitude in a VECTOR form.
%
% Code written by Tianjuan Yang.
%% using projection method
L  = paras(1);
V1 = [-L/2 L/2 0];
V2 = [0 0 sqrt(2)*L/2];
V3 = [-L/2 -L/2 0];
f1 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = [-L/2 -L/2 0];
V2 = [0 0 sqrt(2)*L/2];
V3 = [L/2 -L/2 0];
f2 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = [L/2 -L/2 0];
V2 = [0 0 sqrt(2)*L/2];
V3 = [L/2 L/2 0];
f3 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = [L/2 L/2 0];
V2 = [0 0 sqrt(2)*L/2];
V3 = [-L/2 L/2 0];
f4 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
scattering_amplitude = 2*real(f1 + f2 + f3 + f4);
end