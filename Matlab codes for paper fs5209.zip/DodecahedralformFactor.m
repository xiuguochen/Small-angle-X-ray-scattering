function scattering_amplitude = DodecahedralformFactor(paras, qx, qy, qz)
% Calculate the form factor (scattering amplitude) of a 3D dodecahedral model
%
% Input:
%   - paras: a VECTOR that contains the structural parameters of the model
%   - Qx, Qy, Qz: components of the scattering vector Q along the x,y,z axis.
% Output:
%  - scattering_amplitude: scattering amplitude in a VECTOR form.
%
% Code written by Tianjuan Yang.
%%
a  = paras(1);
L = a/(sqrt(5)-1);
phi = (sqrt(5)+1)/2;
%% Vertex coordinates
v1 = [-L,L,L];v2 = [-L,-L,L];v3 = [L,-L,L];v4 = [L,L,L];v5 = [-L,L,-L];
v6 = [-L,-L,-L];v7 = [L,-L,-L];v8 = [L,L,-L];v9 = [-1/phi*L,0,phi*L];v10 = [-1/phi*L,0,-phi*L];
v11 = [1/phi*L,0,-phi*L];v12 = [1/phi*L,0,phi*L];v13 = [0,-phi*L,1/phi*L];v14 = [0,-phi*L,-1/phi*L];v15 = [0,phi*L,-1/phi*L];
v16 = [0,phi*L,1/phi*L];v17 = [-phi*L,1/phi*L,0];v18 = [-phi*L,-1/phi*L,0];v19 = [phi*L,-1/phi*L,0];v20 = [phi*L,1/phi*L,0];
%% using projection method
V1 = v10;V2 = v6;V3 = v14;
f1 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v10;V2 = v14;V3 = v7;
f2 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v10;V2 = v7;V3 = v11;
f3 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v11;V2 = v7;V3 = v19;
f4 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v11;V2 = v19;V3 = v20;
f5 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v11;V2 = v20;V3 = v8;
f6 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v11;V2 = v8;V3 = v15;
f7 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v11;V2 = v15;V3 = v5;
f8 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v11;V2 = v5;V3 = v10;
f9 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v10;V2 = v5;V3 = v17;
f10 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v10;V2 = v17;V3 = v18;
f11 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v10;V2 = v18;V3 = v6;
f12 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v6;V2 = v18;V3 = v2;
f13 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v6;V2 = v2;V3 = v13;
f14 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v6;V2 = v13;V3 = v14;
f15 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v14;V2 = v13;V3 = v3;
f16 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v14;V2 = v3;V3 = v19;
f17 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v14;V2 = v19;V3 = v7;
f18 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);

scattering_amplitude = 2*real(f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12 +...
f13 + f14 + f15 + f16 + f17 + f18 );

end