function scattering_amplitude = IcosahedralformFactor( paras, qx, qy, qz)
% Calculate the form factor (scattering amplitude) of a 3D icosahedral model
%
% Input:
%   - paras: a VECTOR that contains the structural parameters of the model.
%   - Qx, Qy, Qz: components of the scattering vector Q along the x,y,z axis.
% Output:
%  - scattering_amplitude: scattering amplitude in a VECTOR form.
%
% Code written by Tianjuan Yang.
%%
a  = paras(1);
R = a*sqrt(2*sqrt(5)+10)/4;
m = R*sqrt(50-10*sqrt(5))/10;
n = R*sqrt(50+10*sqrt(5))/10;
%% Vertex coordinates
v0 = [m,0,n];v1 = [m,0,-n];v2 = [-m,0,n];v3 = [-m,0,-n];v4 = [0,n,m];v5 = [0,-n,m];
v6 = [0,n,-m];v7 = [0,-n,-m];v8 = [n,m,0];v9 = [-n,m,0];v10 = [n,-m,0];v11 = [-n,-m,0];
%% using projection method
V1 = v6;V2 = v4;V3 = v8;
f1 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v9;V2 = v4;V3 = v6;
f2 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v6;V2 = v3;V3 = v9;
f3 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v6;V2 = v1;V3 = v3;
f4 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v6;V2 = v8;V3 = v1;
f5 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v8;V2 = v10;V3 = v1;
f6 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v8;V2 = v0;V3 = v10;
f7 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v8;V2 = v4;V3 = v0;
f8 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v4;V2 = v2;V3 = v0;
f9 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v4;V2 = v9;V3 = v2;
f10 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v9;V2 = v11;V3 = v2;
f11 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v9;V2 = v3;V3 = v11;
f12 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v3;V2 = v1;V3 = v7;
f13 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v1;V2 = v10;V3 = v7;
f14 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v10;V2 = v0;V3 = v5;
f15 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v0;V2 = v2;V3 = v5;
f16 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v2;V2 = v11;V3 = v5;
f17 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v3;V2 = v7;V3 = v11;
f18 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v5;V2 = v11;V3 = v7;
f19 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
V1 = v10;V2 = v5;V3 = v7;
f20 =  Orthogonal_tetrahedra_formfactor(V1,V2,V3, qx, qy, qz);
scattering_amplitude = f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12 +...
f13 + f14 + f15 + f16 + f17 + f18 + f19 + f20;

end