%   MATLAB program for the scattering of polyhedron particles.

%   Powered by Nanoscale and Optical Metrology (NOM) Group, Huazhong University of Science and Technology.
%   All Rights Reserved.
%
%   Program revised by Tianjuan Yang. ////////

clear; clc;
addpath(genpath(pwd))
%% simulation condition /////////////////////
global DENSITY
% tic
SDD = 8.5e9;                              % in nanometer, sample to detector distance
Pixel = 172e3;                            % in nanometer, detector's resolution per pixel
Numpixelx = 1475;                         % detector with 1475 pixels along x direction
Numpixely = 1475;                         % detector with 1475 pixels along y direction
wavelength = 0.0729;                      % in nanometer, wave length corresponding to 17 KeV                    
DENSITY = 2.8783;                         % electron density
Thetaf = atand(Pixel*[-Numpixelx/2:Numpixelx/2]/SDD);                                                  % in degree, diffraction angles along x direction
Alphaf = atand(Pixel*[-Numpixely/2:Numpixely/2]/SDD);                                                  % in degree, diffraction angles along y direction
[thetaf, alphaf] = meshgrid(Thetaf,Alphaf);
%% rotation condition /////////////////////
Omega  = 0;                               % in degree, rotation angle along the y-axis
Phi = 0;                                  % in degree, rotation angle along the x-axis
Gamma = 0;                                % in degree, rotation angle along the z-axis
Rz = [cosd(Gamma) sind(Gamma) 0; -sind(Gamma) cosd(Gamma) 0; 0 0 1] ;        
Ry = [cosd(Omega) 0 -sind(Omega);  0 1 0; sind(Omega) 0 cosd(Omega)];        
Rx = [1 0 0; 0 cosd(Phi) sind(Phi); 0 -sind(Phi) cosd(Phi)];                 
R = Rz*Ry*Rx;                             % rotation matrix 
%% computing the distribution of q vector at different orientations
qx =  2*pi/wavelength*cosd(alphaf).*sind(thetaf);
qy =  2*pi/wavelength*sind(alphaf);
qz =  2*pi/wavelength*(cosd(alphaf).*cosd(thetaf) - 1);

Qx = R(1,1)*qx + R(1,2)*qy + R(1,3)*qz;
Qy = R(2,1)*qx + R(2,2)*qy + R(2,3)*qz;
Qz = R(3,1)*qx + R(3,2)*qy + R(3,3)*qz;
%% cube parameters
a  = 30;                                % in nanometer, length along y direction
b  = 20;                                % in nanometer, length along x direction
h  = 40;                                % in nanometer, length along z direction
formfactor_paras = [a,b,h];      
formfactor = CubicformFactor(formfactor_paras, Qx, Qy, Qz);
%% tarpzoidal cross section parameters
% a  = 30;                                % in nanometer, length along y direction
% b  = 20;                                % in nanometer, length along x direction
% h  = 40;                                % in nanometer, length along z direction
% SWA1 = 20;                              % in degree, side wall angle
% SWA2 = 20;                              % in degree, side wall angle
% formfactor_paras = [a,b,h,SWA1,SWA2];    
% formfactor = TrapezoidalFormFactor3D(formfactor_paras, Qx, Qy, Qz);
%% Octahedron parameters
% a = 20;                                   % in nanometer, side length
% formfactor_paras = [a];                  
% formfactor = OctahedralformFactor(formfactor_paras, Qx, Qy, Qz);
%% Dodecahedron parameters
% a  = 20*(sqrt(5)-1);                      % in nanometer, side length
% formfactor_paras = [a];                  
% formfactor = DodecahedralformFactor(formfactor_paras, Qx, Qy, Qz);
%% icosahedron parameters
% a  = 20;                                  % in nanometer, side length
% formfactor_paras = [a];                
% formfactor = IcosahedralformFactor(formfactor_paras, Qx, Qy, Qz);
%% concave cube   
% a = 30;                                   % in nanometer, side length
% b = 3;                                    % in nanometer, depth of concavity
% formfactor_paras = [a,b];               
% formfactor = ConcavecubeformFactor(formfactor_paras, Qx, Qy, Qz);                        
%% plot RSMap
RSMap = abs(formfactor).^2; 
figure
contour(qx,qy,log(RSMap),200)
xlabel('\itq\rm_{\itx\rm} [nm^-^1]', 'FontName', 'Times New Roman', 'FontSize',12);
ylabel('\itq\rm_{\ity\rm} [nm^-^1]', 'FontName', 'Times New Roman', 'FontSize',12);
colorbar
u2 = colorbar;
colormap(jet);
set(get(u2,'title'),'string','log(Intensity)');
title(['Simulated RSM: ','\it\omega\rm =',num2str(Omega),'^o,\it\phi\rm =',num2str(Phi),'^o,\it\gamma\rm =',num2str(Gamma),'^o'],'FontName', 'Times New Roman', 'FontSize',14)
%% plot slices
% figure
% plot(Qx(100,:),log(RSMap(100,:)),'r-',Qx(500,:),log(RSMap(500,:)),'m-',Qx(1000,:),log(RSMap(1000,:)),'b-','Linewidth', 2)
% txt1 = sprintf('\\itq\\rm_{\\ity\\rm} = %f', Qy(50,1));
% txt2 = sprintf('\\itq\\rm_{\\ity\\rm} = %f', Qy(800,1));
% txt3 = sprintf('\\itq\\rm_{\\ity\\rm} = %f', Qy(1400,1));
% xlabel('\itq\rm_{\itx\rm} [nm^-^1]', 'FontName', 'Times New Roman', 'FontSize', 12);
% ylabel('log(intensity) [a.u.]', 'FontName', 'Times New Roman', 'FontSize', 12)
% legend({txt1,txt2,txt3},'FontName', 'Times New Roman', 'Fontsize', 12)

% toc